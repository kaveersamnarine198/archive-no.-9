ARCHIVE NO. 9 — WEBSITE STARTER

FILES
- index.html: complete responsive storefront prototype.

HOW TO PREVIEW
1. Open index.html in a desktop browser.
2. On iPhone, you can upload this file to CodePen or publish the folder using GitHub Pages.
3. The product cards, size selection, bag counter, cart drawer, and WhatsApp order enquiry work in the browser.

BEFORE GOING LIVE
- Product names and prices are examples. Replace them with real details.
- The product illustrations are custom SVG mockups, not photographs of actual garments.
- The order button opens a WhatsApp message draft but does not process payments or guarantee an order.
- Update hello@example.com to your real contact email.
- Add delivery, returns, privacy, and terms information.
- Configure and test a payment provider that supports merchants and settlement in Trinidad and Tobago before taking online payments.

FREE HOSTING
GitHub Pages can host this static website. Create a GitHub repository, upload index.html, then enable Settings > Pages and publish from the main branch/root folder.
